class MyEmp
{
    constructor(name,email,skills,job)
    {
        this.name=name;
        this.email=email;
        this.skills=skills;
        this.job=job;

    }
    
}
export default MyEmp;