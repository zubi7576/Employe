import {combineReducers} from 'redux'
import addRed from './addRed'

const rootReducer = combineReducers(
    {
        addRed
    }
)
export default rootReducer;